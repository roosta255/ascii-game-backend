#include "Role.hpp"

void Role::get(RoleEnum role, std::function<void(const RoleFlyweight&)> consumer) {
    static RoleFlyweight table[ROLE_COUNT] = {
        { 3, 1 }, // ROLE_TINKER
        { 1, 0 }  // ROLE_MINION
    };
    if (role >= 0 && role < ROLE_COUNT) {
        consumer(table[role]);
    }
}
