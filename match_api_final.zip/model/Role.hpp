#pragma once
#include <json/json.h>
#include <functional>

enum RoleEnum {
    ROLE_TINKER,
    ROLE_MINION,
    ROLE_COUNT
};

struct RoleFlyweight {
    int health;
    int buffs;

    void toJson(Json::Value& out) const {
        out["health"] = health;
        out["buffs"] = buffs;
    }

    bool fromJson(const Json::Value& in) {
        if (!in.isMember("health") || !in.isMember("buffs")) return false;
        health = in["health"].asInt();
        buffs = in["buffs"].asInt();
        return true;
    }
};

class Role {
public:
    static void get(RoleEnum role, std::function<void(const RoleFlyweight&)> consumer);
};
